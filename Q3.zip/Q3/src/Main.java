import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        int[] myList =   {10 , 5, 20, 25, 29, 27, 22, 12, 8};

        for (int a = 0; a < myList.length - 1; ++a) {
            for (int b = 0; b < myList.length - 1; ++b) {
                if (myList[b] > myList[b + 1]) {
                    {
                        int temp = myList[b];
                        myList[b] = myList[b + 1];
                        myList[b + 1] = temp;
                        System.out.println(Arrays.toString(myList));//Display the sorted results
                    }
                }


            }
        }
    }
}
