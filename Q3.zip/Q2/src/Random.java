public class Random {


}
