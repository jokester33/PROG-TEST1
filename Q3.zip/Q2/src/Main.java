//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        String[] strArr = new String[50];

        for (int i = 0; i < strArr.length; i++ ){
            strArr[i] = String.valueOf(i /2);
        }
        for (int i = 0; i < strArr.length; i ++){
            System.out.print(strArr[i] + " : ");
        }

    }
}